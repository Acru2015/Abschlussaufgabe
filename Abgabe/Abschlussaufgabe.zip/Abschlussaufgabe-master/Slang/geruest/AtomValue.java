/**
 * Created by Anton on 19.06.2015.
 */
public class AtomValue implements Value {
    @Override
    public String toS() {
        return null;
    }

    @Override
    public int toI() {
        return 0;
    }
}
