public interface Value {

    String toS();

    int toI();


}
