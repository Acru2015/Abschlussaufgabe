public class LexerException extends SlangException {
    public LexerException(SourcePosition position, String message) {
        super(position, message);
    }
}
